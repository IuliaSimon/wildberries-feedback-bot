# Этот код будет работать только в окружении с поддержкой SSL.
# Если ты запускаешь его в ограниченной среде (например, в некоторых песочницах), может не работать из-за отсутствия SSL.

import logging
import os
import openai
import asyncio
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor

# Настройки
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")  # Вставь сюда свой токен от BotFather
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")  # Вставь сюда свой ключ OpenAI
openai.api_key = OPENAI_API_KEY

# Логирование
logging.basicConfig(level=logging.INFO)

# Инициализация бота
bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher(bot)

# Команда /start
@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply("Привет! Я бот для обработки отзывов с Wildberries. Просто пришли мне отзыв, а я сгенерю ответ 💬")

# Обработка текстовых сообщений (отзывы)
@dp.message_handler(content_types=types.ContentType.TEXT)
async def handle_review(message: types.Message):
    user_review = message.text.strip()

    try:
        response = openai.ChatCompletion.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "Ты вежливый и доброжелательный представитель бренда женской одежды. Отвечай кратко, тепло и профессионально."},
                {"role": "user", "content": f"Клиент написал отзыв: {user_review}"}
            ]
        )

        reply_text = response['choices'][0]['message']['content']
        await message.reply("Вот готовый ответ:\n" + reply_text)

    except Exception as e:
        logging.error(f"Ошибка при генерации ответа: {e}")
        await message.reply("Произошла ошибка при генерации ответа. Попробуй позже 🙏")

if __name__ == '__main__':
    try:
        executor.start_polling(dp, skip_updates=True)
    except ModuleNotFoundError as e:
        print("Ошибка: окружение не поддерживает SSL. Попробуй запустить код в полноценной системе (например, на сервере или локальной машине с Python и SSL).")
