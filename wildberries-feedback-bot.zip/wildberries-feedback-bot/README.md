# 🤖 Wildberries Feedback Bot

Бот в Telegram, который принимает отзывы клиентов, отправляет их в GPT и возвращает вежливый ответ, готовый к публикации на Wildberries.

---

## 🚀 Как запустить

### 1. Клонируй репозиторий:
```bash
git clone https://github.com/your-username/wildberries-feedback-bot.git
cd wildberries-feedback-bot
```

### 2. Установи зависимости:
```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 3. Добавь `.env` файл:
Создай `.env` на основе `.env.example` и вставь свои ключи от Telegram и OpenAI.

### 4. Запусти бота:
```bash
python bot.py
```

---

## ☁️ Развёртывание в облаке
Можно использовать [Render.com](https://render.com) или [Railway.app](https://railway.app) — просто задеплой и добавь переменные окружения.

---

## 📬 Что делает бот?

- Получает текстовые отзывы от пользователей.
- Отправляет их в OpenAI GPT-4.
- Возвращает готовый ответ в стиле «бренд с заботой и теплотой».

---

## 📌 Требования

- Python 3.10+
- Наличие SSL в системе
- Аккаунты Telegram + OpenAI

---

## 🧠 Автор

Создан с любовью и автоматизацией ❤️
